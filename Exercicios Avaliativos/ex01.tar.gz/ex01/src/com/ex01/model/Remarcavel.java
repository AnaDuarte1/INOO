package com.ex01.model;

import java.time.LocalDate;

interface Remarcavel {
    boolean remarcarViagem(LocalDate novaDataIda, LocalDate novaDataVolta, String novoDestino);
}

